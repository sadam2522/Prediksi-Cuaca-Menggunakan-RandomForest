Link : https://thecleverprogrammer.com/2020/08/30/predict-weather-with-machine-learning/
Dataset : https://github.com/amankharwal/Website-data/blob/master/GlobalTemperatures.csv
